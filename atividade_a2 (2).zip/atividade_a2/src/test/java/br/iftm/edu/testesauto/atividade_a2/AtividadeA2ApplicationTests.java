package br.iftm.edu.testesauto.atividade_a2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeA2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
